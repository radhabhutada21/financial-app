import React from 'react';
import { DollarSign, TrendingUp, TrendingDown, PiggyBank } from 'lucide-react';
import '../styles/TopCards.css';

const cards = [
  { title: 'Balance', icon: <DollarSign />, valueKey: 'totalBalance', color: '#00FF85', border: '#0052cc' },
  { title: 'Revenue', icon: <TrendingUp />, valueKey: 'totalIncome', color: '#00FF85' },
  { title: 'Expenses', icon: <TrendingDown />, valueKey: 'totalExpenses', color: '#FF6B6B' },
  { title: 'Savings', icon: <PiggyBank />, valueKey: 'savingsRate', color: '#00FF85', isPercent: true },
];

const TopCards = ({ summary }: { summary: any }) => {
  return (
    <div className="top-cards">
      {cards.map(({ title, icon, valueKey, color, border, isPercent }) => (
        <div
          className="card"
          style={border ? { borderColor: border } : {}}
          key={title}
        >
          <div className="icon" style={{ backgroundColor: color + '20', color }}>
            {icon}
          </div>
          <div className="info">
            <p className="label">{title}</p>
            <h3>
              {isPercent ? `${summary[valueKey]}%` : `$${summary[valueKey]?.toLocaleString()}`}
            </h3>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TopCards;
