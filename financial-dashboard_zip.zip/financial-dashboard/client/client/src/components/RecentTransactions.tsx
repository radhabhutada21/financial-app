import React from 'react';
import '../styles/RecentTransactions.css';

const RecentTransactions = ({ data }: { data: any[] }) => {
  return (
    <div className="recent-transactions-card">
      <div className="recent-header">
        <h3 className="recent-title">Recent Transaction</h3>
        <a href="#" className="see-all">See all</a>
      </div>

      <ul className="recent-list">
        {data.slice(0, 6).map((tx, i) => (
          <li key={i} className="recent-entry">
            <img
              className="recent-avatar"
              src={tx.avatar || `https://i.pravatar.cc/150?img=${i + 5}`}
              alt="avatar"
            />
            <div className="recent-info">
              <p className="recent-sub">{tx.type === 'income' ? 'Transfers from' : 'Transfers to'}</p>
              <p className="recent-name">Transaction #{tx.id}</p>
            </div>
            <div className={`amount ${tx.type === 'income' ? 'green' : 'orange'}`}>
              {tx.type === 'income' ? '+' : '-'}${tx.amount.toFixed(2)}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RecentTransactions;
