import React, { useState } from 'react';
import '../styles/ExportModal.css';

const ExportModal = ({
  isOpen,
  onClose,
  onExport,
}: {
  isOpen: boolean;
  onClose: () => void;
  onExport: (data: { filters: any; columns: string[] }) => void;
}) => {
  const [columns, setColumns] = useState([
    'name',
    'date',
    'amount',
    'category',
    'type',
    'status',
  ]);

  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    category: '',
    status: '',
    type: '',
  });

  const toggleColumn = (col: string) => {
    setColumns((prev) =>
      prev.includes(col)
        ? prev.filter((c) => c !== col)
        : [...prev, col]
    );
  };

  const handleExport = () => {
    onExport({ columns, filters });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h3>Export Transactions</h3>

        <div className="columns">
          {['name', 'date', 'amount', 'category', 'type', 'status'].map(
            (col) => (
              <label key={col}>
                <input
                  type="checkbox"
                  checked={columns.includes(col)}
                  onChange={() => toggleColumn(col)}
                />
                {col}
              </label>
            )
          )}
        </div>

        <div className="filters">
          <label>
            Start Date
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) =>
                setFilters({ ...filters, startDate: e.target.value })
              }
            />
          </label>
          <label>
            End Date
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) =>
                setFilters({ ...filters, endDate: e.target.value })
              }
            />
          </label>
          <label>
            Type
            <select
              value={filters.type}
              onChange={(e) =>
                setFilters({ ...filters, type: e.target.value })
              }
            >
              <option value="">All</option>
              <option value="income">Income</option>
              <option value="expense">Expense</option>
            </select>
          </label>
          <label>
            Status
            <select
              value={filters.status}
              onChange={(e) =>
                setFilters({ ...filters, status: e.target.value })
              }
            >
              <option value="">All</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
            </select>
          </label>
        </div>

        <div className="modal-actions">
          <button onClick={onClose} className="cancel-btn">
            Cancel
          </button>
          <button onClick={handleExport} className="export-btn">
            Export CSV
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExportModal;
