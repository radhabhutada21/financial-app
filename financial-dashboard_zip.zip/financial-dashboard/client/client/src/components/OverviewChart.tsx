import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import '../styles/OverviewChart.css';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const income = payload.find((item: any) => item.dataKey === 'income')?.value || 0;
    const expenses = payload.find((item: any) => item.dataKey === 'expenses')?.value || 0;

    return (
      <div className="custom-tooltip-box both">
        <p className="tooltip-label">{label}</p>
        <p className="tooltip-line income">Income: ${income.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
        <p className="tooltip-line expense">Expenses: ${expenses.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
      </div>
    );
  }
  return null;
};


const OverviewChart = ({ data }: { data: any[] }) => {
  return (
    <div className="overview">
      <div className="overview-header">
        <h2>Overview</h2>
        <div className="overview-controls">
          <div className="legend">
            <span className="legend-item green-dot">Income</span>
            <span className="legend-item orange-dot">Expenses</span>
          </div>
          <select className="filter-dropdown" disabled>
            <option>Monthly</option>
          </select>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid stroke="#2a2e40" strokeDasharray="3 3" />
          <XAxis
            dataKey="month"
            stroke="#aaa"
            axisLine={false}
            tickLine={false}
            interval={0}
            tick={{ fontSize: 12 }}
          />
          <YAxis
            stroke="#aaa"
            axisLine={false}
            tickLine={false}
            tickFormatter={(value) => `$${value.toLocaleString()}`}
            tick={{ fontSize: 12 }}
          />
          <Tooltip
            content={<CustomTooltip />}
            isAnimationActive={false}
            cursor={{ stroke: '#444', strokeWidth: 1 }}
          />
          <Line
            type="monotone"
            dataKey="income"
            stroke="#00FF85"
            strokeWidth={3}
            dot={{ r: 4, fill: '#00FF85' }}
            activeDot={{ r: 6, fill: '#00FF85', stroke: '#fff', strokeWidth: 2 }}
          />
          <Line
            type="monotone"
            dataKey="expenses"
            stroke="#FFA500"
            strokeWidth={3}
            dot={{ r: 4, fill: '#FFA500' }}
            activeDot={{ r: 6, fill: '#FFA500', stroke: '#fff', strokeWidth: 2 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default OverviewChart;
