import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from './Sidebar';
import { parseISO, isWithinInterval, eachMonthOfInterval, format } from 'date-fns';
import Topbar from './Topbar';
import TopCards from './TopCards';
import OverviewChart from './OverviewChart';
import RecentTransactions from './RecentTransactions';
import TransactionTable from './TransactionTable';
import ExportModal from './ExportModal';
import { api } from '../api/index';
import '../styles/Dashboard.css';

interface DashboardProps {
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
  const [dashboard, setDashboard] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showExport, setShowExport] = useState(false);
  const [chartData, setChartData] = useState<any[]>([]);
  const [startDate, setStartDate] = useState(new Date(new Date().getFullYear(), 0, 1));
  const [endDate, setEndDate] = useState(new Date());

  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  useEffect(() => {
    if (!token) {
      navigate('/');
      return;
    }

    const fetchAll = async () => {
      try {
        const dashboardData = await api.getDashboardData(token);
        const txData = await api.getTransactions({}, token);
        setDashboard(dashboardData);
        setTransactions(txData.transactions);

        const monthsInYear = eachMonthOfInterval({
          start: new Date(new Date().getFullYear(), 0, 1),
          end: new Date(new Date().getFullYear(), 11, 1),
        }).map((date) => ({
          month: format(date, 'MMM'),
          income: 0,
          expenses: 0,
        }));

        const fullChartData = monthsInYear.map((m) => {
          const found = dashboardData.monthlyTrends.find((d: any) =>
            format(new Date(d.month + '-01'), 'MMM') === m.month
          );
          return {
            ...m,
            income: found?.income || 0,
            expenses: found?.expenses || 0,
          };
        });

        setChartData(fullChartData);
      } catch (err: any) {
        console.error('Error loading dashboard:', err);
        localStorage.removeItem('token');
        onLogout();
        navigate('/');
      } finally {
        setLoading(false);
      }
    };

    fetchAll();
  }, [token, navigate, onLogout]);

  const handleExport = (exportData: any) => {
    api.exportCSV(exportData, token!);
  };

  const filteredTransactions = transactions.filter((tx: any) =>
    isWithinInterval(parseISO(tx.date), { start: startDate, end: endDate })
  );

  if (loading || !dashboard) {
    return <div className="loading">Loading dashboard...</div>;
  }

  return (
    <div className="dashboard-wrapper">
      <Sidebar />
      <div className="dashboard-main">
        <Topbar onLogout={onLogout} />
        <div className="dashboard-content-container">
          <div className="section-card">
            <TopCards summary={dashboard.summary} />
          </div>

          <div className="section-row">
            <div className="section-card chart-card">
              <OverviewChart data={chartData} />
            </div>
            <div className="section-card recent-card">
              <RecentTransactions data={dashboard.recentTransactions} />
            </div>
          </div>

          <div className="section-card table-card">
            <TransactionTable
              data={filteredTransactions}
              startDate={startDate}
              endDate={endDate}
              setStartDate={setStartDate}
              setEndDate={setEndDate}
            />
          </div>

          <div className="export-wrapper">
            <button onClick={() => setShowExport(true)} className="export-btn">
              Export CSV
            </button>
          </div>
        </div>

        <ExportModal
          isOpen={showExport}
          onClose={() => setShowExport(false)}
          onExport={handleExport}
        />
      </div>
    </div>
  );
};

export default Dashboard;
