import React, { useState } from 'react';
import '../styles/TransactionTable.css';

const TransactionTable = ({
  data,
  startDate,
  endDate,
  setStartDate,
  setEndDate
}: {
  data: any[];
  startDate: Date;
  endDate: Date;
  setStartDate: (date: Date) => void;
  setEndDate: (date: Date) => void;
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const formatDate = (date: Date) => date.toISOString().split('T')[0];

  const filteredData = data.filter((tx: any) => {
    const txDate = new Date(tx.date);
    return (
      txDate >= startDate &&
      txDate <= endDate &&
      tx.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="transaction-table">
      <div className="table-header">
        <h2>Transactions</h2>
        <div className="filters">
          <input
            type="text"
            placeholder="Search for anything..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <input
            type="date"
            value={formatDate(startDate)}
            onChange={(e) => setStartDate(new Date(e.target.value))}
          />
          <input
            type="date"
            value={formatDate(endDate)}
            onChange={(e) => setEndDate(new Date(e.target.value))}
          />
        </div>
      </div>

      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Date</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((tx: any, index: number) => (
              <tr key={index}>
                <td className="name">
                  <img src={`https://i.pravatar.cc/150?img=${index + 5}`} alt={tx.name} />
                  <span className="tx-name">{tx.name}</span>
                </td>
                <td>{new Date(tx.date).toDateString()}</td>
                <td>
                  <span className={`pill amount-pill ${tx.amount >= 0 ? 'green' : 'orange'}`}>
                    {tx.amount >= 0 ? `+$${tx.amount}` : `-$${Math.abs(tx.amount)}`}
                  </span>
                </td>
                <td>
                  <span className={`pill status-pill ${tx.status.toLowerCase()}`}>
                    {tx.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TransactionTable;
