import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import {
  Home,
  CreditCard,
  BarChart2,
  User,
  MessageCircle,
  Settings
} from 'lucide-react';
import '../styles/Sidebar.css';

const Sidebar = () => {
  return (
    <aside className="sidebar">
      {/* Yellow right-side scroll bar (scrolls with content) */}
      <div className="scroll-accent" />

      <div className="sidebar-logo">
        <span className="logo-icon" />
        <span className="logo-text">Penta</span>
      </div>

      <nav className="sidebar-nav">
        <ul>
          <li className="active"><Home size={18} /><span>Dashboard</span></li>
          <li><CreditCard size={18} /><span>Transactions</span></li>
          <li><CreditCard size={18} /><span>Wallet</span></li>
          <li><BarChart2 size={18} /><span>Analytics</span></li>
          <li><User size={18} /><span>Personal</span></li>
          <li><MessageCircle size={18} /><span>Message</span></li>
          <li><Settings size={18} /><span>Setting</span></li>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
