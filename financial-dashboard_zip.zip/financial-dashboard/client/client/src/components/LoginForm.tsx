import React, { useState } from 'react';
import { toast } from 'react-toastify';
import '../styles/LoginForm.css';
import { api } from '../api/index';

interface LoginFormProps {
  onLogin: (credentials: { username: string; password: string }) => void;
  loading: boolean;
}

const LoginForm: React.FC<LoginFormProps> = ({ onLogin, loading }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [isSignup, setIsSignup] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      if (isSignup) {
        await api.register({ username, password, email });
        toast.success('Signup successful! Logging you in... 🎉', {
          autoClose: 2000,
        });
      }

      await onLogin({ username, password });
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
      toast.error(err.message || 'Login failed! Please check your credentials.', {
        autoClose: 3000,
      });
    }
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2 className="login-title">
          {isSignup ? 'Create your Penta Account' : 'Welcome to '}
          {!isSignup && <span className="highlight">Penta</span>}
        </h2>

        {error && <p className="error">{error}</p>}

        {isSignup && (
          <input
            className="login-input"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            required
          />
        )}

        <input
          className="login-input"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Username"
          required
        />
        <input
          className="login-input"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          required
        />

        <button className="login-button" type="submit" disabled={loading}>
          {loading ? 'Please wait...' : isSignup ? 'Sign Up' : 'Sign In'}
        </button>

        <p className="toggle-text">
          {isSignup ? 'Already have an account?' : "Don't have an account?"}
          <button
            type="button"
            className="toggle-button"
            onClick={() => {
              setIsSignup(!isSignup);
              setError('');
            }}
          >
            {isSignup ? 'Login' : 'Sign Up'}
          </button>
        </p>
      </form>
    </div>
  );
};

export default LoginForm;
