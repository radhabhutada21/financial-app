import React, { useState, useRef, useEffect } from 'react';
import { LogOut, Bell, ChevronDown } from 'lucide-react';
import '../styles/Topbar.css';

const Topbar = ({ onLogout }: { onLogout: () => void }) => {
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="topbar">
      <h2 className="topbar-title">Dashboard</h2>
      <div className="topbar-right">
        <input type="text" className="search-input" placeholder="Search..." />
        <Bell className="icon" size={20} />
        <div className="profile" onClick={() => setOpen(!open)} ref={dropdownRef}>
          <img src="https://i.pravatar.cc/300" alt="User" />
          <ChevronDown className="dropdown-icon" size={16} />
          {open && (
            <div className="dropdown">
              <button onClick={onLogout}>
                <LogOut size={16} /> Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Topbar;
