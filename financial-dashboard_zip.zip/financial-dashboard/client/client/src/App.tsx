import { Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import LoginForm from './components/LoginForm';
import { useState } from 'react';
import { api } from './api/index';

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [loading, setLoading] = useState(false);

  const handleLogin = async (credentials: { username: string; password: string }) => {
    setLoading(true);
    try {
      const { token } = await api.login(credentials);
      localStorage.setItem('token', token);
      setToken(token);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
  };

  return (
    <Routes>
      <Route
        path="/"
        element={
          token ? (
            <Navigate to="/dashboard" />
          ) : (
            <LoginForm onLogin={handleLogin} loading={loading} />
          )
        }
      />
      <Route
        path="/dashboard"
        element={
          token ? (
            <Dashboard onLogout={handleLogout} />
          ) : (
            <Navigate to="/" />
          )
        }
      />
    </Routes>
  );
}

export default App;
