const BASE_URL = '/api';

export const api = {
 login: async (credentials: { username: string; password: string }) => {
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials),
    });
    if (!res.ok) throw new Error('Login failed');
    return await res.json();
  },

  register: async (data: { username: string; password: string; email: string }) => {
  const res = await fetch(`${BASE_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  const response = await res.json();

  // Show the actual message sent by backend, like "User exists"
  if (!res.ok) throw new Error(response.message || 'Registration failed');
  return response;
},


  getDashboardData: async (token: string) => {
    const res = await fetch(`${BASE_URL}/dashboard/analytics`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Failed to load dashboard data');
  return data;
},

  getTransactions: async (query: any, token: string) => {
    const params = new URLSearchParams(query).toString();
    const res = await fetch(`${BASE_URL}/transactions?${params}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return await res.json();
  },

  exportCSV: async (body: any, token: string) => {
    const res = await fetch(`${BASE_URL}/transactions/export`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(body),
    });
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transactions.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  },
};
