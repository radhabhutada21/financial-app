// server/server.ts
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { MongoClient, Db, ObjectId } from 'mongodb';
import { Parser } from 'json2csv';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret_key' ;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/financial_app';

app.use(cors());
app.use(express.json());

let db: Db;

const connectDB = async () => {
  const client = new MongoClient(MONGO_URI);
  await client.connect();
  db = client.db('financial_app');
  console.log('Connected to MongoDB');
};

interface User {
  _id?: ObjectId;
  username: string;
  password: string;
  email: string;
}

interface Transaction {
  _id?: ObjectId;
  name: string;
  date: Date;
  amount: number;
  category: string;
  status: string;
  type: 'income' | 'expense';
  description?: string;
  user: string;
}

interface AuthRequest extends express.Request {
  user?: { userId: string; username: string };
}

const authenticateToken = (req: AuthRequest, res: express.Response, next: express.NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Token required' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: 'Invalid token' });
    req.user = user as any;
    next();
  });
};

// Auth Routes
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await db.collection<User>('users').findOne({ username });
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
  const token = jwt.sign({ userId: user._id, username: user.username }, JWT_SECRET, { expiresIn: '24h' });
  res.json({ token, user: { id: user._id, username: user.username, email: user.email } });
});

app.post('/api/auth/register', async (req, res) => {
  const { username, password, email } = req.body;
  const exists = await db.collection<User>('users').findOne({ $or: [{ username }, { email }] });
  if (exists) return res.status(409).json({ message: 'User exists' });
  const hashedPassword = await bcrypt.hash(password, 10);
  const result = await db.collection<User>('users').insertOne({ username, password: hashedPassword, email });
  const token = jwt.sign({ userId: result.insertedId, username }, JWT_SECRET, { expiresIn: '24h' });
  res.status(201).json({ token, user: { id: result.insertedId, username, email } });
});

// Transactions Fetch
app.get('/api/transactions', authenticateToken, async (req: AuthRequest, res) => {
  const { page = '1', limit = '10', search, category, status, type, startDate, endDate, sortBy = 'date', sortOrder = 'desc' } = req.query;
  const skip = (Number(page) - 1) * Number(limit);
  const filter: any = { user: req.user?.userId };

  if (search) filter.$or = [
    { name: { $regex: search, $options: 'i' } },
    { description: { $regex: search, $options: 'i' } }
  ];
  if (category) filter.category = category;
  if (status) filter.status = status;
  if (type) filter.type = type;
  if (startDate || endDate) {
    filter.date = {};
    if (startDate) filter.date.$gte = new Date(startDate as string);
    if (endDate) filter.date.$lte = new Date(endDate as string);
  }

  const sort: any = {};
  sort[sortBy as string] = sortOrder === 'asc' ? 1 : -1;

  const transactions = await db.collection<Transaction>('transactions')
    .find(filter).sort(sort).skip(skip).limit(Number(limit)).toArray();
  const total = await db.collection<Transaction>('transactions').countDocuments(filter);

  res.json({ transactions, pagination: { current: Number(page), total: Math.ceil(total / Number(limit)), count: total } });
});

// Dashboard Analytics
app.get('/api/dashboard/analytics', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const userId = req.user?.userId;

    const [incomeAgg, expenseAgg] = await Promise.all([
      db.collection<Transaction>('transactions').aggregate([
        { $match: { user: userId, type: 'income' } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ]).toArray(),
      db.collection<Transaction>('transactions').aggregate([
        { $match: { user: userId, type: 'expense' } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ]).toArray()
    ]);

    const totalIncome = incomeAgg[0]?.total || 0;
    const totalExpenses = expenseAgg[0]?.total || 0;
    const totalBalance = totalIncome - totalExpenses;
    const savingsRate = totalIncome > 0 ? ((totalBalance / totalIncome) * 100).toFixed(2) : '0';

    const monthlyTrendsRaw = await db.collection<Transaction>('transactions').aggregate([
      { $match: { user: userId } },
      {
        $group: {
          _id: {
            year: { $year: '$date' },
            month: { $month: '$date' },
            type: '$type'
          },
          total: { $sum: '$amount' }
        }
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } }
    ]).toArray();

    const trendMap = new Map();
    monthlyTrendsRaw.forEach(t => {
      const key = `${t._id.year}-${String(t._id.month).padStart(2, '0')}`;
      const obj = trendMap.get(key) || { income: 0, expenses: 0 };
      t._id.type === 'income' ? obj.income += t.total : obj.expenses += t.total;
      trendMap.set(key, obj);
    });
    const monthlyTrends = Array.from(trendMap.entries()).map(([month, val]) => ({ month, ...val }));

    const categoryBreakdown = await db.collection<Transaction>('transactions').aggregate([
      { $match: { user: userId, type: 'expense' } },
      {
        $group: {
          _id: '$category',
          total: { $sum: '$amount' },
          count: { $sum: 1 }
        }
      },
      { $sort: { total: -1 } }
    ]).toArray();

    const recentTransactions = await db.collection<Transaction>('transactions')
      .find({ user: userId }).sort({ date: -1 }).limit(5).toArray();

    res.json({
      summary: { totalIncome, totalExpenses, totalBalance, savingsRate },
      monthlyTrends,
      categoryBreakdown,
      recentTransactions
    });
  } catch (error) {
    console.error('Analytics error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Export as CSV
app.post('/api/transactions/export', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { columns, filters } = req.body;
    const filter: any = { user: req.user?.userId };

    if (filters) {
      if (filters.category) filter.category = filters.category;
      if (filters.status) filter.status = filters.status;
      if (filters.type) filter.type = filters.type;
      if (filters.startDate || filters.endDate) {
        filter.date = {};
        if (filters.startDate) filter.date.$gte = new Date(filters.startDate);
        if (filters.endDate) filter.date.$lte = new Date(filters.endDate);
      }
    }

    const transactions = await db.collection<Transaction>('transactions').find(filter).toArray();
    const fields = columns || ['name', 'date', 'amount', 'category', 'status', 'type'];
    const parser = new Parser({ fields });
    const csv = parser.parse(transactions);

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=\"transactions.csv\"');
    res.send(csv);
  } catch (error) {
    console.error('Export error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Seeding Route
app.post('/api/seed', async (req, res) => {
  try {
    const filePath = path.join(__dirname, 'transactions.json');
    const raw = fs.readFileSync(filePath, 'utf-8');
    const transactions = JSON.parse(raw);
    const userIds = [...new Set(transactions.map((tx: any) => tx.user_id))];

    await db.collection('users').deleteMany({ username: { $in: userIds } });
    const users = await Promise.all((userIds as string[]).map(async (uid: string) => {
      const hashed = await bcrypt.hash('password123', 10);
      const u = await db.collection('users').insertOne({ username: uid, email: `${uid}@example.com`, password: hashed });
      return { username: uid, _id: u.insertedId };
    }));

    const userMap = Object.fromEntries(users.map(u => [u.username, u._id.toString()]));
    const cleaned = transactions.map((tx: any) => ({
      name: `Transaction #${tx.id}`,
      date: new Date(tx.date),
      amount: tx.amount,
      category: tx.category,
      status: tx.status.toLowerCase(),
      type: tx.category?.toLowerCase().includes('revenue') ? 'income' : 'expense',
      description: 'Imported from JSON',
      user: userMap[tx.user_id]
    }));

    await db.collection('transactions').deleteMany({});
    await db.collection('transactions').insertMany(cleaned);

    res.json({ message: 'Seeded successfully' });
  } catch (e) {
    console.error('Seeding error:', e);
    res.status(500).json({ message: 'Seed error' });
  }
});

const start = async () => {
  await connectDB();
  app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
};
start();
